import { Outlet } from "react-router-dom"
import Navbar from "../components/Navbar"
import Home from "../components/Home"



function Mainlayout() {
  return (
      <>
      <Navbar/>
          <main>
              <Outlet/>
          </main>
        
      </>
  )
}

export default Mainlayout