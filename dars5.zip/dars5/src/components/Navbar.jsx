import React from 'react';
import Sitelogo from "../image/Sitelogo.svg"
import Navlogo from "../image/navlogo.svg"
const Navbar = () => {
  return (
    <nav className="bg-gray-800 p-4">
      <div className="containers flex items-center justify-between">
        <div className="text-white content-between  "><img  src={Sitelogo} alt="" /> <p className='pt-2' >There are 7 total invoices</p> </div>
        <ul className="space-x-4 flex items-center">
      <li><details className="dropdown">
  <summary className="m-1 btn">open or close</summary>
  <ul className="p-2  shadow menu dropdown-content z-[1] bg-base-100 rounded-box w-52">
    <li><a>Item 1</a></li>
    <li><a>Item 2</a></li>
  </ul>
</details></li>
      <li className='flex items-center gap-4 px-2 btns   rounded-3xl'> <img src={Navlogo} className='flex bg-slate-50 h-8  rounded-2xl' alt="" /> <p className='py-4 flex dark:text-white'>New Invoice</p> </li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;